package com.paxata.custom.clustering;

import java.io.Serializable;
import java.util.List;

/**
 * Extend this class to write a customer clustering algorithm.
 */
public interface ClusterAlgorithm extends Serializable {

  /**
   * @return the display name for this algorithm
   */
  public String getDisplayName();

  /**
   * This is *the* clustering algorithm. If parameters are necessary for the algorithm, then access them in this method.
   * For example, the n-gram algorithm requires a size parameter that is updated and passed in by the UI, so n-gram's
   * implementation of encode accesses the size parameter.
   *
   * @param s the input value on which to find clusters of
   * @return the hash of the input string
   */
  public String encode(String s);

  /**
   * @return the associated parameters for this algorithm, if any
   */
  public List<ClusterAlgorithmParam> getParams();
}
