package com.paxata.custom.clustering;

import java.io.Serializable;

/**
 * Stores parameter information for a cluster algorithm.
 * <p/>
 * For example, the n-gram algorithm requires a size parameter. The implementation of that
 * algorithm initializes an instance of ClusterAlgorithmParam with a displayName of "NGram Size",
 * paramType of Integer, and a default paramValue of 1. An end user can update the paramValue
 * by using the Paxata application.
 * <p/>
 * The displayName is the name that the end user will see in the UI.
 * Possible values for paramType are Integer, Float, Boolean, and String.
 * Depending on the paramType, paramValue should also be an Integer, Float, Boolean, or String, respectively.
 */
public class ClusterAlgorithmParam implements Serializable {
  public final String displayName;
  public final AlgoParamType paramType;
  public Object paramValue;

  /**
   * Create an instance of this class to store parameter information for a cluster algorithm.
   * 
   * @param displayName the name that the end user will see in the UI
   * @param paramType   possible values are Integer, Float, Boolean, and String
   * @param paramValue  should also be an Integer, Float, Boolean, or String, respecting the paramType
   */
  public ClusterAlgorithmParam(String displayName,
                               AlgoParamType paramType,
                               Object paramValue) {
    this.displayName = displayName;
    this.paramType = paramType;
    this.paramValue = paramValue;
  }
  
  /**
   * Sets the paramValue for this param.
   * Algorithm implementors should NOT call this method directly; it is called by the Paxata server.
   */
  public void setValue(String value) {
    paramValue = paramType.convert(value);
  }

  public enum AlgoParamType {
    Integer {
      @Override
      public Object convert(String value) {
        return java.lang.Integer.valueOf(value);
      }
    },
    Float {
      @Override
      public Object convert(String value) {
        return java.lang.Float.valueOf(value);
      }
    },
    Boolean {
      @Override
      public Object convert(String value) {
        return java.lang.Boolean.valueOf(value);
      }
    },
    String {
      @Override
      public Object convert(String value) {
        return value;
      }
    };

    public abstract Object convert(String value);
  }
}
